// components/metadata/template-selector-improved.jsx
"use client";

import { useState, useMemo } from "react";
import { ChevronsUpDown, Search, X, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Card, CardContent } from "@/components/ui/card";
import useMetadataStore from "@/store/useMetadataStore";

const TemplateSelector = () => {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const {
    templates = [],
    selectedTemplate,
    setSelectedTemplate,
    loading,
  } = useMetadataStore();

  const filteredTemplates = useMemo(() => {
    if (!searchQuery.trim()) return templates;
    const q = searchQuery.toLowerCase();
    return templates.filter(
      (t) =>
        t.Name?.toLowerCase().includes(q) ||
        t.Description?.toLowerCase().includes(q)
    );
  }, [templates, searchQuery]);

  const handleSelect = (template) => {
    setSelectedTemplate(template);
    setSearchQuery("");
    setOpen(false);
  };

  const handleClear = (e) => {
    e.stopPropagation();
    setSelectedTemplate(null);
    setSearchQuery("");
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-sm text-gray-500">
          Loading templates...
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-gray-200 rounded-2xl">
      <CardContent className={"rounded-2xl"}>
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            {/* div instead of button to avoid nested button */}
            <div
              role="combobox"
              aria-expanded={open}
              tabIndex={0}
              onClick={() => setOpen(!open)}
              className={cn(
                "w-full cursor-pointer select-none rounded-xl border px-4 py-3",
                "flex items-center justify-between",
                "hover:bg-white bg-white transition",
                selectedTemplate
                  ? "border-blue-200"
                  : "border-gray-200 text-gray-500"
              )}
            >
              <div className="flex items-center gap-3 truncate">
                {selectedTemplate ? (
                  <>
                    <FileText className="w-4 h-4 text-blue-600" />
                    <span className="truncate">
                      {selectedTemplate.Name}
                    </span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 text-gray-400" />
                    <span>Search and select a template</span>
                  </>
                )}
              </div>

              <div className="flex items-center gap-2">
                {selectedTemplate && (
                  <button
                    onClick={handleClear}
                    type="button"
                    className="p-1 hover:bg-gray-200 rounded"
                  >
                    <X className="w-4 h-4 text-gray-500" />
                  </button>
                )}
                <ChevronsUpDown className="w-4 h-4 text-gray-400" />
              </div>
            </div>
          </PopoverTrigger>

          <PopoverContent
            align="start"
            className="p-0 w-[var(--radix-popover-trigger-width)]"
          >
            {/* Search input */}
            <div className="flex items-center border-b px-3">
              <Search className="mr-2 h-4 w-4 text-gray-400" />
              <input
                className="h-11 w-full bg-transparent text-sm outline-none"
                placeholder="Type to search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* List */}
            <div className="max-h-64 overflow-y-auto">
              {filteredTemplates.length === 0 ? (
                <p className="p-4 text-sm text-gray-500 text-center">
                  No templates found
                </p>
              ) : (
                filteredTemplates.map((template) => (
                  <button
                    key={template.id ?? template._id ?? template.Name}
                    onClick={() => handleSelect(template)}
                    type="button"
                    className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex gap-2"
                  >
                    <FileText className="w-4 h-4 mt-0.5 text-gray-400" />
                    <div>
                      <div className="font-medium">{template.Name}</div>
                      {template.Description && (
                        <div className="text-xs text-gray-500 truncate">
                          {template.Description}
                        </div>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </PopoverContent>
        </Popover>
      </CardContent>
    </Card>
  );
};

export default TemplateSelector;
