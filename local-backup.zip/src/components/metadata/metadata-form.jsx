// components/metadata/metadata-form-improved.jsx
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  AlertCircle,
  CheckCircle,
  Info,
  Loader2,
  FileText,
  RefreshCcw,
  Save,
  Sparkles,
} from "lucide-react";

import TemplateSelector from "./template-selector";
import DynamicFormFields from "./dynamic-form-fields";
import useMetadataStore from "@/store/useMetadataStore";

const MetadataForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    selectedTemplate,
    formData,
    error,
    successMessage,
    loading,
    validateForm,
    resetFormData,
    setError,
    setSuccessMessage,
    clearMessages,
  } = useMetadataStore();

  /* -------------------------------- effects ------------------------------- */

  useEffect(() => {
    if (!error && !successMessage) return;

    const timer = setTimeout(clearMessages, 5000);
    return () => clearTimeout(timer);
  }, [error, successMessage, clearMessages]);

  /* -------------------------------- handlers ------------------------------- */

  const handleSubmit = async (e) => {
    e.preventDefault();
    clearMessages();

    if (!validateForm()) return;

    try {
      setIsSubmitting(true);

      const payload = {
        templateId: selectedTemplate.ID,
        templateName: selectedTemplate.Name,
        metadata: formData,
        timestamp: new Date().toISOString(),
      };

      console.log("Submitting metadata:", payload);

      await new Promise((r) => setTimeout(r, 1500));
      setSuccessMessage("Metadata saved successfully!");
    } catch (err) {
      setError(err?.message || "Failed to save metadata");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    resetFormData();
    clearMessages();
  };

  /* -------------------------------- metrics -------------------------------- */

  const filledFieldsCount = Object.values(formData).filter(
    (v) => v !== null && v !== undefined && String(v).trim() !== ""
  ).length;

  const totalFieldsCount = selectedTemplate?.Fields?.length ?? 0;

  const progressPercentage =
    totalFieldsCount > 0
      ? Math.round((filledFieldsCount / totalFieldsCount) * 100)
      : 0;

  /* -------------------------------- render -------------------------------- */

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <form onSubmit={handleSubmit} className="space-y-6">

          {/* ------------------------------- Alerts ------------------------------ */}
          {error && (
            <Card className="border-red-200 bg-gradient-to-br from-red-50 to-red-100/40">
              <CardContent className="flex gap-3 py-5">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <div>
                  <p className="text-sm font-semibold text-red-900">Error</p>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {successMessage && (
            <Card className="border-green-200 bg-gradient-to-br from-green-50 to-green-100/40">
              <CardContent className="flex gap-3 py-5">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-semibold text-green-900">Success</p>
                  <p className="text-sm text-green-700">{successMessage}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* -------------------------- Template Selector ------------------------- */}
          <TemplateSelector />

          {/* -------------------------- Dynamic Fields ---------------------------- */}
          {selectedTemplate && (
            <Card className="border-gray-200 rounded-2xl shadow-none">
              <CardContent className="rounded-2xl bg-white">
                <DynamicFormFields />
              </CardContent>
            </Card>
          )}

          {/* -------------------------- Action Buttons ---------------------------- */}
          {selectedTemplate && (
            <div className="sticky bottom-4 z-10">
              <Card className="rounded-2xl border-gray-200 shadow-xl">
                <CardContent className="flex flex-col items-center justify-between gap-4 p-4 sm:flex-row">
                  <div className="hidden text-sm text-gray-600 sm:block">
                    {progressPercentage === 100 ? (
                      <span className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="h-4 w-4" />
                        All fields completed
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-blue-600" />
                        {totalFieldsCount - filledFieldsCount} field(s) remaining
                      </span>
                    )}
                  </div>

                  <div className="flex w-full gap-3 sm:w-auto">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleReset}
                      disabled={isSubmitting || loading}
                      className="flex-1 gap-2 sm:flex-none"
                    >
                      <RefreshCcw className="h-4 w-4" />
                      Reset
                    </Button>

                    <Button
                      type="submit"
                      disabled={isSubmitting || loading}
                      className="flex-1 gap-2 rounded-full bg-blue-500 sm:flex-none"
                    >
                      {isSubmitting || loading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Saving…
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4" />
                          Save
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* ----------------------------- Empty State ---------------------------- */}
          {!selectedTemplate && (
            <Card className="rounded-2xl border-2 border-dashed border-gray-300 bg-gray-50">
              <CardContent className="py-16 text-center space-y-4">
                <div className="mx-auto inline-flex rounded-2xl bg-gray-100 p-5">
                  <FileText className="h-14 w-14 text-gray-400" />
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    No Template Selected
                  </h3>
                  <p className="mt-1 text-sm text-gray-600">
                    Select a template to begin adding document metadata.
                  </p>
                </div>

                <div className="inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 py-2">
                  <Sparkles className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">
                    Tip: Use search to find templates faster
                  </span>
                </div>
              </CardContent>
            </Card>
          )}

        </form>
      </div>
    </div>
  );
};

export default MetadataForm;
