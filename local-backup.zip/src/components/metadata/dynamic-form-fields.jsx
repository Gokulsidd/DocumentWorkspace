// components/metadata/dynamic-form-fields.jsx
"use client";

import { useCallback, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";
import useMetadataStore from "@/store/useMetadataStore";

/* -------------------------------------------------------------------------- */
/*                                  Component                                 */
/* -------------------------------------------------------------------------- */

const DynamicFormFields = () => {
  const { selectedTemplate, formData, setFormData } = useMetadataStore();

  const fields = useMemo(
    () => selectedTemplate?.Fields ?? [],
    [selectedTemplate]
  );

  const handleChange = useCallback(
    (fieldId, value) => {
      setFormData(fieldId, value);
    },
    [setFormData]
  );

  if (!selectedTemplate) return null;

  if (fields.length === 0) {
    return (
      <div className="rounded-xl border border-dashed bg-gray-50 p-8 text-center text-sm text-gray-500">
        No fields available for this template
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {fields.map((field) => {
        const value = formData[field.ID] ?? "";
        const isFilled = String(value).trim() !== "";

        return (
          <div
            key={field.ID}
            className="space-y-2 border-b border-gray-100 pb-6 last:border-none last:pb-0"
          >
            {/* Label */}
            <div className="flex flex-wrap items-center gap-2">
              <Label className="flex items-center gap-2 font-semibold">
                {isFilled && (
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                )}
                {field.Name}
              </Label>

              {field.IsRequired && (
                <span className="text-sm text-red-500">*</span>
              )}

              {field.IsMultiValue && (
                <span className="text-sm text-red-500">{field.IsMultiValue}</span>
              )}


              <Badge variant="outline" className="text-xs">
                {field.PropType}
              </Badge>
            </div>

            {/* Description */}
            {field.Description && (
              <p className="text-xs text-gray-600">{field.Description}</p>
            )}

            {/* Field */}
            <FieldRenderer
              field={field}
              value={value}
              onChange={(val) => handleChange(field.ID, val)}
            />
          </div>
        );
      })}
    </div>
  );
};

export default DynamicFormFields;

/* -------------------------------------------------------------------------- */
/*                               Field Renderer                               */
/* -------------------------------------------------------------------------- */

function FieldRenderer({ field, value, onChange }) {
  const type = field.PropType?.toLowerCase();

  if (type === "date") {
    return (
      <Input
        type="date"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full"
      />
    );
  }

  if (type === "list") {
    return (
      <ListSelectField field={field} value={value} onChange={onChange} />
    );
  }

  // Default: string
  const isLongText = field.Length > 120;

  if (isLongText) {
    return (
      <Input
        value={value}
        placeholder={`Enter ${field.Name.toLowerCase()}...`}
        onChange={(e) => onChange(e.target.value)}
        className="w-full"
      />
    );
  }

  return (
    <Input
      type="text"
      value={value}
      placeholder={`Enter ${field.Name.toLowerCase()}...`}
      maxLength={field.Length || undefined}
      onChange={(e) => onChange(e.target.value)}
      className="w-full"
    />
  );
}

/* -------------------------------------------------------------------------- */
/*                            List (Dropdown) Field                           */
/* -------------------------------------------------------------------------- */

function ListSelectField({ field, value, onChange }) {
  const items = useMemo(() => {
    if (!Array.isArray(field.ListItem)) return [];
    return field.ListItem.map((i) => i.trim()).filter(Boolean);
  }, [field.ListItem]);

  if (items.length === 0) {
    return (
      <Input
        placeholder={`Enter ${field.Name.toLowerCase()}...`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }

  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder={`Select ${field.Name.toLowerCase()}...`} />
      </SelectTrigger>

      <SelectContent>
        {items.map((item) => (
          <SelectItem key={item} value={item}>
            {item}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
